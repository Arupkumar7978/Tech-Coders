//============================================================================
// Name        : Gully-Cricket-App.cpp
// Author      : 
// Version     :
// Copyright   : @Gully-akp Reserved .
// Description : Small Cricket Game
//============================================================================

#include <iostream>
#include<string>
#include<ctime>
#include<unistd.h>

using namespace std;

class Cricket{

public:
	int runs;
	string	TeamName_A,TeamName_B;
	void display(){
		cout<<"\t----------------------------------------------------"<<endl;
			cout<<"\t|=============== Gully Cricket App ================|"<<endl;
			cout<<"\t----------------------------------------------------"<<endl;
			sleep(3);
			cout<<"\t\t\tWelcome To Gully Cricket\n"<<endl;
			sleep(2);
			cout<<"Press Enter key To Start the Game"<<endl;
			cin.get();
	}
	void setTeamName(string A,string B){

		cout<<"Enter First Team Name:";
			getline(cin,A);
			cout<<"\nEnter Second Team Name:";
			getline(cin,B);
		this->TeamName_A = A;
		this->TeamName_B = B;
		cout<<"\n\t    **Today's Match**"<<endl;
		cout<<"\t\t"<<TeamName_A<<" VS "<<TeamName_B<<endl;

	}

	void displayPlayers(){

		cout<<"Press Enter key To Diplay The Player Details.."<<endl;
		cin.get();
		cout<<"***************** Team-A:"<<TeamName_A<<" ********************* "<<endl;
		sleep(2);
		cout<<"1.MS Dhoni\n2.Virat Kholi\n3.Deepak Chahar"<<endl;
		cout<<"***************** Team-B:"<<TeamName_B<<" ********************* "<<endl;
		sleep(2);
		cout<<"1.Rohit Sharma\n2.KL Rahul\n3.Jasprit Bumrah"<<endl;
		cout<<"***************** 1 Over Match ********************* "<<endl;


	}

	void display_A(){
	cout << "\nPress Enter to start first inning "<<endl;
		cin.get();
		sleep(2);
		cout<<"\t\t*First Inning started*\n\n";
}

void firstinns(){

	cout<<"\t------ Team A is Batting Team------"<<endl;
	 srand((unsigned) time(0));
	 int choose = 1 + (rand() % 3);

	 switch(choose){

	   case 1:
		   cout<<"MS Dhoni";
		   break;

	   case 2:
		   cout<<"Virat Kholi";
		   break;

	   case 3:
		   cout<<"Deepak Chahar";
		   break;

	   default:
		   cout<<"Invalid ...";
		   break;
	 }
	 cout<<" is the batsman from batting team\n"<<endl;
	 sleep(2);
	 cout<<"\t------Team B is Bowling Team------"<<endl;

	 switch(choose){
	 	 case 1:
	 		 cout<<"Rohit Sharma";
	 		 break;
	 	 case 2:
	 		 cout<<"KL Rahul";
	 	   	 break;
	 	 case 3:
	 		 cout<<"Jasprit Bumrah";
	 		 break;
	 	 default:
	 		 cout<<"Invalid ..";
	 }
	 cout<<" is the bowler from bowling team\n"<<endl;
}


void display_B(){
	cout << "\nPress Enter to start second inning ";
		cin.get();
		sleep(2);
		cout<<"\t\t*second Inning started*\n\n";

}
void secondinns(){

	cout<<"\t------Team B is Batting Team------"<<endl;
		 srand((unsigned) time(0));
		 int choose = 1 + (rand() % 3);

		 switch(choose){

		   case 1:
			   cout<<"Rohit Sharma";
			   break;

		   case 2:
			   cout<<"KL Rahul";
			   break;

		   case 3:
			   cout<<"Jasprit Bumrah";
			   break;

		   default:
			   cout<<"Invalid ...";
			   break;
		 }
		 cout<<" is the batsman from batting team\n"<<endl;
		 sleep(2);
		 cout<<"\t------Team A is Bowling Team------"<<endl;

		 switch(choose){
		 	 case 1:
		 		 cout<<"MS Dhoni";
		 		 break;
		 	 case 2:
		 		 cout<<"Virat Kholi";
		 	   	 break;
		 	 case 3:
		 		 cout<<"Deepak Chahar";
		 		 break;
		 	 default:
		 		 cout<<"Invalid ..";
		 }
		 cout<<" is the bowler from bowling team\n"<<endl;
	}
void winner(int A_score, int B_score){
		if(A_score > B_score)
		{
			cout<<"\n\t\tTeam "<<TeamName_A<<" is Winner ."<<endl;
		}
		else if(A_score < B_score)
		{
			cout<<"\n\tTeam "<<TeamName_B<<" is Winner ."<<endl;
		}
		else
		{
			cout<<"Match Draw !!"<<endl;
		}

}
void end(){
	sleep(1);
		cout<<"\n******************************************************\n"<<endl;
		cout<<"\t\t   Thank You"<<endl;
		cout<<"\n******************************************************\n"<<endl;
	sleep(1);
		cout<<"\t\t@Team Gully Cricket || 2022"<<endl;

}

friend int play();

};

int play();

int main() {
	string teamA,teamB;
	Cricket T;
	T.display();
	T.setTeamName(teamA, teamB);
	T.displayPlayers();

	//TEAM A
	Cricket TeamA;
	TeamA.display_A();
	TeamA.firstinns();
	TeamA.runs=play();

	//TEAM B
		Cricket TeamB;
		TeamB.display_B();
		TeamB.secondinns();
		TeamB.runs=play();

		T.winner(TeamA.runs,TeamB.runs);
		T.end();
	return 0;
}
int play(){
		int run,b=1,balls,totalRuns=0;
		    srand((unsigned) time(0));

		    for (int i= 0; i < 5; i++) {
		    run = (rand() % 6) + 1;
		    cout << "\nPress Enter To Bowl.... ";
		    cin.get();
		    sleep(2);
		    switch(run){
		      case 0:
		    	  cout<<"Commentary: Ooppsss .. No Run"<<endl;
		    	  break;
		      case 1:
		    	  cout<<"Commentary: Nice Shot"<<endl;
		    	  break;
		      case 2:
		     	  cout<<"Commentary: Good Shot "<<endl;
		     	  break;
		      case 3:
		      	  cout<<"Commentary: Nice Drive"<<endl;
		          break;
		      case 4:
		      	  cout<<"Commentary: Good Drive"<<endl;
		      	  break;
		      case 5:
		          cout<<"Commentary: Good Shot"<<endl;
		          break;
		      case 6:
		    	  cout<<"Commentary: Awesome Shot"<<endl;
		    	  break;
		      default:
		    	  cout<<"Error";
		    	  break;
		    }
		    sleep(1);
		    cout << "runs:" <<run<< endl;
		    totalRuns=totalRuns+run;
		    }
		     cout << "\nPress Enter to view final score.... ";
		     cin.get();
		     sleep(1);
		     cout<<"Final run scored by the team:"<<totalRuns<<endl;

		     return run;
	};

